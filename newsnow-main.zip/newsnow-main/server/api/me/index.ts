export default defineEventHandler(() => {
  return {
    hello: "world",
  }
})
