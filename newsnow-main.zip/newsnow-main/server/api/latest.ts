export default defineEventHandler(async () => {
  return {
    v: Version,
  }
})
